import json

MAX_IN_GROUP = 30  

def make_record(stream, groups, students):
    stream = str(stream).strip()
    if not stream:
        raise ValueError("Название потока не может быть пустым")
    try:
        groups = int(groups)
        if isinstance(students, str):
            students = students.replace(";", ",").split(",")
        students = [int(s) for s in students if str(s).strip()]
    except (TypeError, ValueError):
        raise ValueError(f"Поток «{stream}»: количество групп и студентов должно быть целыми числами")
    if groups <= 0:
        raise ValueError(f"Поток «{stream}»: количество групп должно быть больше нуля")
    if any(not 1 <= s <= MAX_IN_GROUP for s in students):
        raise ValueError(f"Поток «{stream}»: в группе должно быть от 1 до {MAX_IN_GROUP} студентов")
    if len(students) != groups:
        raise ValueError(f"Поток «{stream}»: указано групп {groups}, а чисел студентов {len(students)}")
    return {"stream": stream, "groups": groups, "students": students}


def load_json(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("В файле должен быть список записей")
    try:
        return [make_record(r["stream"], r["groups"], r["students"]) for r in data]
    except (KeyError, TypeError):
        raise ValueError("У каждой записи должны быть поля stream, groups, students")


def save_json(path, records):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)

def total(record):
    return sum(record["students"])

def distribution(records):
    return sorted(records, key=total, reverse=True)

def pick_for_farm(records, need):
    reachable = {0: []} 
    for i, record in enumerate(records):
        t = total(record)
        for s, idx in list(reachable.items()):
            if s >= need: 
                continue
            new_sum = s + t
            if new_sum not in reachable or len(idx) + 1 < len(reachable[new_sum]):
                reachable[new_sum] = idx + [i]
    enough = [s for s in reachable if s >= need]
    if not enough:
        return None
    best = min(enough)
    return best, [records[i] for i in reachable[best]]

def matches(record, field, query):
    query = query.strip().lower()
    if not query:
        return True
    values = {
        "stream": [record["stream"]],
        "groups": [record["groups"]],
        "students": record["students"],
        "total": [total(record)],
    }
    keys = values.keys() if field == "all" else [field]
    return any(str(v).lower().startswith(query) for key in keys for v in values[key])
