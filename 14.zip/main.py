import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

import db

SEARCH_FIELDS = {
    "Все поля": "all",
    "Поток": "stream",
    "Кол-во групп": "groups",
    "Студентов в группе": "students",
    "Всего студентов": "total",
}
DEFAULT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.json")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ЛР 14. Список студентов (вариант 20)")
        self.geometry("860x580")
        self.minsize(720, 500)
        self.records = []

        self._build_search()
        self._build_buttons()
        self._build_form()
        self._build_table()

        if os.path.exists(DEFAULT_FILE):
            try:
                self.records = db.load_json(DEFAULT_FILE)
            except (OSError, ValueError) as e:
                messagebox.showwarning("Файл data.json", str(e))
        self.refresh()

    def _build_search(self):
        frame = ttk.LabelFrame(self, text="Поиск по полям (значение начинается с введённого текста)")
        frame.pack(fill="x", padx=8, pady=4)
        self.search_field = ttk.Combobox(frame, values=list(SEARCH_FIELDS), state="readonly", width=18)
        self.search_field.current(0)
        self.search_field.pack(side="left", padx=4, pady=4)
        self.search_field.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh())
        self.search_entry = ttk.Entry(frame, textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True, padx=4)
        ttk.Button(frame, text="Поиск по полям", command=self.search).pack(side="left", padx=4)
        ttk.Button(frame, text="Сбросить", command=self.show_all).pack(side="left", padx=4)

    def _build_buttons(self):
        self.status = ttk.Label(self, anchor="w")
        self.status.pack(side="bottom", fill="x", padx=10, pady=(0, 4))

        frame = ttk.Frame(self)
        frame.pack(side="bottom", fill="x", padx=8, pady=4)
        buttons = [
            ("Импорт JSON в БД", self.import_json),
            ("Сохранить в JSON", self.save_json),
            ("Просмотр БД", self.show_all),
            ("Вычислить", self.calculate),
            ("Очистить БД", self.clear_db),
            ("Ввести запись", self.add_record),
            ("Перейти к записи", self.go_to),
            ("Редактировать запись", self.edit_record),
            ("Удалить запись", self.delete_record),
        ]
        for i, (text, command) in enumerate(buttons):
            ttk.Button(frame, text=text, command=command).grid(row=i // 5, column=i % 5, sticky="ew", padx=3, pady=3)
        for col in range(5):
            frame.columnconfigure(col, weight=1)

    def _build_form(self):
        frame = ttk.LabelFrame(self, text="Ввод и редактирование записи")
        frame.pack(side="bottom", fill="x", padx=8, pady=4)
        self.entries = {}
        fields = [
            ("stream", "Название потока"),
            ("groups", "Количество групп"),
            ("students", "Студентов в группах (через запятую)"),
        ]
        for row, (key, label) in enumerate(fields):
            ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", padx=4, pady=2)
            entry = ttk.Entry(frame)
            entry.grid(row=row, column=1, sticky="ew", padx=4, pady=2)
            self.entries[key] = entry
        ttk.Label(frame, text="№ записи").grid(row=0, column=2, padx=(16, 4))
        self.goto_entry = ttk.Entry(frame, width=6)
        self.goto_entry.grid(row=0, column=3, padx=4)
        frame.columnconfigure(1, weight=1)

    def _build_table(self):
        frame = ttk.LabelFrame(self, text="База данных")
        frame.pack(fill="both", expand=True, padx=8, pady=4)
        columns = ("num", "stream", "groups", "students", "total")
        titles = ("№", "Поток", "Групп", "Студентов по группам", "Всего")
        widths = (40, 160, 70, 320, 80)
        self.tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        for col, title, width in zip(columns, titles, widths):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w" if col in ("stream", "students") else "center")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        field = SEARCH_FIELDS[self.search_field.get()]
        query = self.search_var.get()
        shown = 0
        for i, r in enumerate(self.records):
            if db.matches(r, field, query):
                students = ", ".join(map(str, r["students"]))
                self.tree.insert("", "end", iid=str(i), values=(i + 1, r["stream"], r["groups"], students, db.total(r)))
                shown += 1
        self.status.config(text=f"Показано записей: {shown} из {len(self.records)}")

    def fill_form(self, record):
        values = {
            "stream": record["stream"],
            "groups": record["groups"],
            "students": ", ".join(map(str, record["students"])),
        }
        for key, entry in self.entries.items():
            entry.delete(0, "end")
            entry.insert(0, values[key])

    def clear_form(self):
        for entry in self.entries.values():
            entry.delete(0, "end")

    def read_form(self):
        try:
            return db.make_record(self.entries["stream"].get(), self.entries["groups"].get(),
                                  self.entries["students"].get())
        except ValueError as e:
            messagebox.showerror("Ошибка ввода", str(e))
            return None

    def selected_index(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("Нет выбора", "Сначала выберите запись в таблице")
            return None
        return int(selection[0])

    def select_row(self, index):
        iid = str(index)
        if self.tree.exists(iid):
            self.tree.selection_set(iid)
            self.tree.focus(iid)
            self.tree.see(iid)

    def on_select(self, event=None):
        selection = self.tree.selection()
        if selection:
            index = int(selection[0])
            self.fill_form(self.records[index])
            self.goto_entry.delete(0, "end")
            self.goto_entry.insert(0, index + 1)

    def import_json(self):
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json"), ("Все файлы", "*.*")])
        if not path:
            return
        try:
            data = db.load_json(path)
        except (OSError, ValueError) as e:
            messagebox.showerror("Ошибка импорта", str(e))
            return
        if self.records:
            answer = messagebox.askyesnocancel("Импорт", "Добавить записи к текущей БД?\n"
                                                         "Да — добавить, Нет — заменить БД")
            if answer is None:
                return
            self.records = self.records + data if answer else data
        else:
            self.records = data
        self.refresh()
        messagebox.showinfo("Импорт", f"Загружено записей: {len(data)}")

    def save_json(self):
        path = filedialog.asksaveasfilename(defaultextension=".json", initialfile="data.json",
                                            filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            db.save_json(path, self.records)
        except OSError as e:
            messagebox.showerror("Ошибка сохранения", str(e))
            return
        messagebox.showinfo("Сохранение", f"Сохранено записей: {len(self.records)}")

    def show_all(self):
        self.search_var.set("")

    def search(self):
        self.refresh()
        self.search_entry.focus_set()

    def add_record(self):
        record = self.read_form()
        if record:
            self.records.append(record)
            self.refresh()
            self.select_row(len(self.records) - 1)

    def go_to(self):
        try:
            number = int(self.goto_entry.get())
        except ValueError:
            messagebox.showerror("Ошибка", "Введите номер записи числом")
            return
        if not 1 <= number <= len(self.records):
            messagebox.showerror("Ошибка", f"Номер должен быть от 1 до {len(self.records)}")
            return
        self.show_all()
        self.select_row(number - 1)

    def edit_record(self):
        index = self.selected_index()
        if index is None:
            return
        record = self.read_form()
        if record:
            self.records[index] = record
            self.refresh()
            self.select_row(index)

    def delete_record(self):
        index = self.selected_index()
        if index is None:
            return
        if messagebox.askyesno("Удаление", f"Удалить поток «{self.records[index]['stream']}»?"):
            del self.records[index]
            self.clear_form()
            self.refresh()

    def clear_db(self):
        if self.records and messagebox.askyesno("Очистка", "Удалить все записи из БД?"):
            self.records = []
            self.clear_form()
            self.refresh()

    def calculate(self):
        if not self.records:
            messagebox.showinfo("Вычисление", "БД пуста")
            return
        need = simpledialog.askinteger("Работа в колхозе", "Сколько студентов требуется?",
                                       parent=self, minvalue=1)
        if need is None:
            return
        self.show_results(db.distribution(self.records), db.pick_for_farm(self.records, need), need)

    def show_results(self, dist, farm, need):
        win = tk.Toplevel(self)
        win.title("Вычисленные характеристики")
        win.geometry("640x560")

        lines = ["Распределение потоков по совокупному количеству студентов:"]
        for place, r in enumerate(dist, 1):
            lines.append(f"  {place}. {r['stream']} — {db.total(r)} чел. ({r['groups']} гр.)")
        all_students = sum(db.total(r) for r in dist)
        lines += [f"Всего студентов: {all_students}", "", f"Потребность колхоза: {need} чел."]
        if farm:
            farm_sum, chosen = farm
            names = ", ".join(r["stream"] for r in chosen)
            lines.append(f"Отправить потоки: {names}")
            lines.append(f"Итого: {farm_sum} чел. (сверх потребности: {farm_sum - need})")
        else:
            chosen = []
            lines.append(f"Студентов не хватает: во всех потоках только {all_students} чел.")

        text = tk.Text(win, height=12, wrap="word")
        text.insert("1.0", "\n".join(lines))
        text.config(state="disabled")
        text.pack(fill="x", padx=8, pady=8)

        ttk.Label(win, text="Зелёным отмечены потоки для работы в колхозе").pack(anchor="w", padx=8)
        frame = ttk.Frame(win)
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        canvas = tk.Canvas(frame, bg="white")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.draw_chart(canvas, dist, chosen)

    def draw_chart(self, canvas, dist, chosen):
        chosen_ids = {id(r) for r in chosen}
        left, bar_h, gap, chart_w = 110, 22, 8, 420
        max_total = db.total(dist[0])
        for i, r in enumerate(dist):
            y = 10 + i * (bar_h + gap)
            w = chart_w * db.total(r) / max_total
            color = "#4caf50" if id(r) in chosen_ids else "#5b8def"
            canvas.create_text(left - 6, y + bar_h / 2, text=r["stream"], anchor="e")
            canvas.create_rectangle(left, y, left + w, y + bar_h, fill=color, outline="")
            canvas.create_text(left + w + 6, y + bar_h / 2, text=str(db.total(r)), anchor="w")
        canvas.configure(scrollregion=(0, 0, left + chart_w + 50, 20 + len(dist) * (bar_h + gap)))


if __name__ == "__main__":
    App().mainloop()
